/*
 * RAAD HOLDING GROUP — About Section
 * Style: Warm Editorial Luxury
 * ES/EN language support
 */

import { useEffect, useRef, useState } from "react";
import { useLang } from "@/contexts/LanguageContext";

const ABOUT_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663366769268/5rAkXcv2tyCLbTxCEwe5y8/raad-about-bg-K7qEKptANQLdRmJom6sx9X.webp";

function useIntersection(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);
  return { ref, visible };
}

export default function About() {
  const { ref: leftRef, visible: leftVisible } = useIntersection(0.1);
  const { ref: rightRef, visible: rightVisible } = useIntersection(0.1);
  const { ref: valuesRef, visible: valuesVisible } = useIntersection(0.1);
  const { t } = useLang();

  const founders = t("about_founders") as unknown as { name: string; role: string }[];
  const values = t("about_values") as unknown as { arabic: string; label: string; description: string }[];

  return (
    <section id="nosotros" className="bg-[#1B2A4A] relative overflow-hidden">
      <div className="h-1 w-full bg-gradient-to-r from-[#B8860B] via-[#D4A017] to-[#B8860B]" />

      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-28">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Left: Text */}
          <div
            ref={leftRef}
            style={{
              opacity: leftVisible ? 1 : 0,
              transform: leftVisible ? "translateX(0)" : "translateX(-40px)",
              transition: "opacity 0.8s ease, transform 0.8s ease",
            }}
          >
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-px bg-[#B8860B]" />
              <span className="text-[#B8860B] text-xs tracking-[0.4em] font-medium" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                {t("about_eyebrow") as string}
              </span>
            </div>

            <div
              className="text-8xl text-white/5 font-bold mb-4 leading-none select-none"
              style={{ fontFamily: "'Cormorant Garamond', serif", direction: "rtl" }}
            >
              رعد
            </div>

            <h2
              className="text-white leading-tight mb-8 -mt-8"
              style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(2rem, 4vw, 3.5rem)", fontWeight: 700 }}
            >
              {t("about_headline_1") as string}
              <br />
              <em className="text-[#B8860B]">{t("about_headline_2") as string}</em>
            </h2>

            <div className="space-y-5 text-white/70 leading-relaxed" style={{ fontFamily: "'Lato', sans-serif", fontSize: "0.95rem" }}>
              <p>{t("about_p1") as string}</p>
              <p>
                {t("about_p2") as string}{" "}
                <em className="text-white/90">{t("about_p2_em") as string}</em>
              </p>
              <p>{t("about_p3") as string}</p>
            </div>

            <div className="mt-10 pt-8 border-t border-white/10">
              <p className="text-[#B8860B] text-xs tracking-widest mb-4" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                {t("about_founders_label") as string}
              </p>
              <div className="grid grid-cols-2 gap-3">
                {founders.map((founder) => (
                  <div key={founder.name} className="flex flex-col">
                    <span className="text-white text-sm font-medium" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                      {founder.name}
                    </span>
                    <span className="text-white/40 text-xs" style={{ fontFamily: "'Lato', sans-serif" }}>
                      {founder.role}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Image */}
          <div
            ref={rightRef}
            style={{
              opacity: rightVisible ? 1 : 0,
              transform: rightVisible ? "translateX(0)" : "translateX(40px)",
              transition: "opacity 0.8s ease 0.2s, transform 0.8s ease 0.2s",
            }}
          >
            <div className="relative">
              <img
                src={ABOUT_BG}
                alt="Barranquilla skyline"
                className="w-full object-cover"
                style={{ height: "480px" }}
              />
              <div
                className="absolute -bottom-4 -right-4 w-full h-full border border-[#B8860B]/40 pointer-events-none"
                style={{ zIndex: -1 }}
              />
              <div
                className="absolute bottom-6 left-6 right-6 p-6"
                style={{ background: "rgba(27, 42, 74, 0.92)", backdropFilter: "blur(8px)" }}
              >
                <p className="text-[#B8860B] text-xs tracking-widest mb-2" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                  {t("about_hq_label") as string}
                </p>
                <p className="text-white text-lg font-semibold" style={{ fontFamily: "'Cormorant Garamond', serif" }}>
                  {t("about_hq_city") as string}
                </p>
                <p className="text-white/60 text-sm" style={{ fontFamily: "'Lato', sans-serif" }}>
                  {t("about_hq_sub") as string}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Values grid */}
        <div
          ref={valuesRef}
          className="mt-24 pt-16 border-t border-white/10"
          style={{
            opacity: valuesVisible ? 1 : 0,
            transform: valuesVisible ? "translateY(0)" : "translateY(30px)",
            transition: "opacity 0.7s ease, transform 0.7s ease",
          }}
        >
          <p className="text-[#B8860B] text-xs tracking-[0.4em] font-medium mb-10" style={{ fontFamily: "'Montserrat', sans-serif" }}>
            {t("about_values_label") as string}
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {values.map((value, i) => (
              <div
                key={value.label}
                className="border-t border-[#B8860B]/30 pt-6"
                style={{
                  opacity: valuesVisible ? 1 : 0,
                  transform: valuesVisible ? "translateY(0)" : "translateY(20px)",
                  transition: `opacity 0.6s ease ${i * 0.1 + 0.2}s, transform 0.6s ease ${i * 0.1 + 0.2}s`,
                }}
              >
                <div
                  className="text-3xl text-[#B8860B]/40 mb-3 leading-none"
                  style={{ fontFamily: "'Cormorant Garamond', serif", direction: "rtl" }}
                >
                  {value.arabic}
                </div>
                <h4 className="text-white text-lg font-semibold mb-2" style={{ fontFamily: "'Cormorant Garamond', serif" }}>
                  {value.label}
                </h4>
                <p className="text-white/50 text-sm leading-relaxed" style={{ fontFamily: "'Lato', sans-serif" }}>
                  {value.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
