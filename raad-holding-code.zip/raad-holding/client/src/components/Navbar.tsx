/*
 * RAAD HOLDING GROUP — Navbar
 * Style: Warm Editorial Luxury
 * Transparent on top, cream on scroll
 * ES/EN language toggle
 */

import { useState, useEffect } from "react";
import { useLang } from "@/contexts/LanguageContext";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const { lang, toggleLang, t } = useLang();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { label: t("nav_inicio") as string, href: "#inicio" },
    { label: t("nav_portafolio") as string, href: "#portafolio" },
    { label: t("nav_nosotros") as string, href: "#nosotros" },
    { label: t("nav_contacto") as string, href: "#contacto" },
  ];

  const handleNavClick = (href: string) => {
    setMenuOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-[#FAF7F2]/95 backdrop-blur-md shadow-sm border-b border-[#B8860B]/20"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12 flex items-center justify-between h-20">
        {/* Logo */}
        <a
          href="#inicio"
          onClick={(e) => { e.preventDefault(); handleNavClick("#inicio"); }}
          className="flex flex-col leading-none group"
        >
          <span
            className={`font-serif text-3xl font-bold tracking-widest transition-colors duration-300 ${
              scrolled ? "text-[#1B2A4A]" : "text-white"
            }`}
            style={{ fontFamily: "'Cormorant Garamond', serif", letterSpacing: "0.15em" }}
          >
            RAAD
          </span>
          <span
            className="text-[9px] tracking-[0.35em] font-medium text-[#B8860B]"
            style={{ fontFamily: "'Montserrat', sans-serif" }}
          >
            HOLDING GROUP
          </span>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link.href}
              onClick={() => handleNavClick(link.href)}
              className={`animated-link text-[11px] tracking-widest font-medium transition-colors duration-300 ${
                scrolled ? "text-[#1B2A4A]" : "text-white/90 hover:text-white"
              }`}
              style={{ fontFamily: "'Montserrat', sans-serif", letterSpacing: "0.12em" }}
            >
              {(link.label as string).toUpperCase()}
            </button>
          ))}

          {/* Language Toggle */}
          <button
            onClick={toggleLang}
            className={`flex items-center gap-1.5 px-3 py-1.5 border text-[11px] tracking-widest font-semibold transition-all duration-300 ${
              scrolled
                ? "border-[#1B2A4A]/30 text-[#1B2A4A] hover:border-[#B8860B] hover:text-[#B8860B]"
                : "border-white/40 text-white/90 hover:border-white hover:text-white"
            }`}
            style={{ fontFamily: "'Montserrat', sans-serif" }}
            aria-label="Toggle language"
          >
            <span className={lang === "es" ? "text-[#B8860B]" : "opacity-50"}>ES</span>
            <span className="opacity-30">|</span>
            <span className={lang === "en" ? "text-[#B8860B]" : "opacity-50"}>EN</span>
          </button>
        </nav>

        {/* Mobile right side: lang toggle + hamburger */}
        <div className="md:hidden flex items-center gap-3">
          {/* Mobile Language Toggle */}
          <button
            onClick={toggleLang}
            className={`flex items-center gap-1 px-2.5 py-1 border text-[10px] tracking-widest font-semibold transition-all duration-300 ${
              scrolled
                ? "border-[#1B2A4A]/30 text-[#1B2A4A]"
                : "border-white/40 text-white/90"
            }`}
            style={{ fontFamily: "'Montserrat', sans-serif" }}
          >
            <span className={lang === "es" ? "text-[#B8860B]" : "opacity-50"}>ES</span>
            <span className="opacity-30">|</span>
            <span className={lang === "en" ? "text-[#B8860B]" : "opacity-50"}>EN</span>
          </button>

          {/* Hamburger */}
          <button
            className={`flex flex-col gap-1.5 p-2 ${scrolled ? "text-[#1B2A4A]" : "text-white"}`}
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Menu"
          >
            <span className={`block w-6 h-0.5 bg-current transition-all duration-300 ${menuOpen ? "rotate-45 translate-y-2" : ""}`} />
            <span className={`block w-6 h-0.5 bg-current transition-all duration-300 ${menuOpen ? "opacity-0" : ""}`} />
            <span className={`block w-6 h-0.5 bg-current transition-all duration-300 ${menuOpen ? "-rotate-45 -translate-y-2" : ""}`} />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`md:hidden overflow-hidden transition-all duration-400 bg-[#FAF7F2] border-t border-[#B8860B]/20 ${
          menuOpen ? "max-h-80 opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <div className="px-6 py-6 flex flex-col gap-5">
          {navLinks.map((link) => (
            <button
              key={link.href}
              onClick={() => handleNavClick(link.href)}
              className="text-left text-sm tracking-widest text-[#1B2A4A] font-medium hover:text-[#B8860B] transition-colors"
              style={{ fontFamily: "'Montserrat', sans-serif" }}
            >
              {(link.label as string).toUpperCase()}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
}
