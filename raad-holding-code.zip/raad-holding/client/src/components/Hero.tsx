/*
 * RAAD HOLDING GROUP — Hero Section
 * Style: Warm Editorial Luxury
 * Full-screen hero with ES/EN language support
 */

import { useEffect, useState } from "react";
import { useLang } from "@/contexts/LanguageContext";

const HERO_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663366769268/5rAkXcv2tyCLbTxCEwe5y8/raad-hero-bg-2mmb85uf6c2MYp2WhiwNkZ.webp";

export default function Hero() {
  const [visible, setVisible] = useState(false);
  const { t } = useLang();

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section
      id="inicio"
      className="relative min-h-screen flex items-center overflow-hidden"
      style={{
        backgroundImage: `url(${HERO_BG})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-[#0D1929]/85 via-[#1B2A4A]/70 to-[#0D1929]/40" />

      {/* Arabic geometric pattern overlay */}
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23B8860B' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}
      />

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-12 pt-24 pb-16">
        <div className="max-w-3xl">
          {/* Eyebrow */}
          <div
            className={`flex items-center gap-4 mb-8 transition-all duration-700 ${
              visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            <div className="w-12 h-px bg-[#B8860B]" />
            <span
              className="text-[#B8860B] text-xs tracking-[0.4em] font-medium"
              style={{ fontFamily: "'Montserrat', sans-serif" }}
            >
              {t("hero_location") as string}
            </span>
          </div>

          {/* Main headline */}
          <h1
            className={`text-white leading-[0.9] mb-6 transition-all duration-700 delay-200 ${
              visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontSize: "clamp(3.5rem, 8vw, 7rem)",
              fontWeight: 700,
            }}
          >
            {t("hero_headline_1") as string}
            <br />
            <em className="text-[#B8860B] not-italic">{t("hero_headline_2") as string}</em>
            <br />
            {t("hero_headline_3") as string}
          </h1>

          {/* Subheadline */}
          <p
            className={`text-white/75 text-lg leading-relaxed mb-12 max-w-xl transition-all duration-700 delay-300 ${
              visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
            style={{ fontFamily: "'Lato', sans-serif" }}
          >
            {t("hero_sub") as string}
          </p>

          {/* CTAs */}
          <div
            className={`flex flex-wrap gap-4 transition-all duration-700 delay-400 ${
              visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            <button
              onClick={() => document.querySelector("#portafolio")?.scrollIntoView({ behavior: "smooth" })}
              className="px-8 py-4 bg-[#B8860B] text-white text-xs tracking-widest font-semibold hover:bg-[#9A7209] transition-colors duration-300"
              style={{ fontFamily: "'Montserrat', sans-serif" }}
            >
              {t("hero_cta_portfolio") as string}
            </button>
            <button
              onClick={() => document.querySelector("#nosotros")?.scrollIntoView({ behavior: "smooth" })}
              className="px-8 py-4 border border-white/50 text-white text-xs tracking-widest font-semibold hover:bg-white/10 transition-colors duration-300"
              style={{ fontFamily: "'Montserrat', sans-serif" }}
            >
              {t("hero_cta_about") as string}
            </button>
          </div>
        </div>

        {/* Stats row */}
        <div
          className={`mt-20 pt-10 border-t border-white/20 grid grid-cols-2 md:grid-cols-4 gap-8 transition-all duration-700 delay-500 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          {[
            { num: "4", labelKey: "hero_stat_1_label" },
            { num: "10+", labelKey: "hero_stat_2_label" },
            { num: "500+", labelKey: "hero_stat_3_label" },
            { num: "253+", labelKey: "hero_stat_4_label" },
          ].map((stat) => (
            <div key={stat.labelKey} className="text-white">
              <div
                className="text-4xl font-bold text-[#B8860B] leading-none mb-1"
                style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic" }}
              >
                {stat.num}
              </div>
              <div
                className="text-xs text-white/60 tracking-wider"
                style={{ fontFamily: "'Montserrat', sans-serif" }}
              >
                {t(stat.labelKey as any) as string}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/50">
        <span className="text-[10px] tracking-widest" style={{ fontFamily: "'Montserrat', sans-serif" }}>
          SCROLL
        </span>
        <div className="w-px h-12 bg-gradient-to-b from-white/50 to-transparent animate-pulse" />
      </div>
    </section>
  );
}
