/*
 * RAAD HOLDING GROUP — Contact Section
 * Style: Warm Editorial Luxury
 * ES/EN language support
 */

import { useEffect, useRef, useState } from "react";
import { useLang } from "@/contexts/LanguageContext";

function useIntersection(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);
  return { ref, visible };
}

export default function Contact() {
  const { ref, visible } = useIntersection(0.1);
  const { t } = useLang();
  const [formData, setFormData] = useState({ name: "", email: "", company: "", interest: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const inputClass = `
    w-full px-4 py-3 bg-white border border-[#E5DDD0] text-[#1B2A4A] text-sm
    focus:outline-none focus:border-[#B8860B] transition-colors duration-200
    placeholder:text-[#9CA3AF]
  `;

  const contactItems = [
    {
      label: t("contact_email_label") as string,
      value: "info@fittglobal.com",
      href: "mailto:info@fittglobal.com",
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
        </svg>
      ),
    },
    {
      label: t("contact_phone_label") as string,
      value: "+57 300 332 3856",
      href: "https://wa.me/573003323856",
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
        </svg>
      ),
    },
    {
      label: t("contact_location_label") as string,
      value: t("contact_location_value") as string,
      href: null,
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
          <path d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      ),
    },
  ];

  const bizLinks = [
    { name: "Raad Sports", url: "https://raad-sports-m9j8tkfj.manus.space/", color: "#1E40AF" },
    { name: "Fitt Global", url: "https://fittglobal-qjwiezeo.manus.space", color: "#4D7C0F" },
    { name: "Handasa", url: "https://handasa-env-dghx92zu.manus.space", color: "#4A5E2A" },
    { name: "Star Beauty Brands", url: null, color: "#9D4E6B" },
  ];

  return (
    <section id="contacto" className="py-28 bg-[#FAF7F2]">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div
          ref={ref}
          className="grid grid-cols-1 lg:grid-cols-2 gap-16"
          style={{
            opacity: visible ? 1 : 0,
            transform: visible ? "translateY(0)" : "translateY(30px)",
            transition: "opacity 0.8s ease, transform 0.8s ease",
          }}
        >
          {/* Left: Info */}
          <div>
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-px bg-[#B8860B]" />
              <span className="text-[#B8860B] text-xs tracking-[0.4em] font-medium" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                {t("contact_eyebrow") as string}
              </span>
            </div>

            <h2
              className="text-[#1B2A4A] leading-tight mb-8"
              style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(2rem, 4vw, 3.5rem)", fontWeight: 700 }}
            >
              {t("contact_headline_1") as string}
              <br />
              <em className="text-[#B8860B]">{t("contact_headline_2") as string}</em>
            </h2>

            <p className="text-[#6B7280] leading-relaxed mb-12 text-sm" style={{ fontFamily: "'Lato', sans-serif" }}>
              {t("contact_sub") as string}
            </p>

            <div className="space-y-6">
              {contactItems.map((item) => (
                <div key={item.label} className="flex items-start gap-4">
                  <div className="w-10 h-10 flex items-center justify-center flex-shrink-0 text-[#B8860B]" style={{ background: "#B8860B15" }}>
                    {item.icon}
                  </div>
                  <div>
                    <p className="text-[10px] tracking-widest text-[#9CA3AF] mb-0.5" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                      {item.label.toUpperCase()}
                    </p>
                    {item.href ? (
                      <a
                        href={item.href}
                        target={item.href.startsWith("http") ? "_blank" : undefined}
                        rel="noopener noreferrer"
                        className="text-[#1B2A4A] text-sm hover:text-[#B8860B] transition-colors animated-link"
                        style={{ fontFamily: "'Lato', sans-serif" }}
                      >
                        {item.value}
                      </a>
                    ) : (
                      <span className="text-[#1B2A4A] text-sm" style={{ fontFamily: "'Lato', sans-serif" }}>
                        {item.value}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-12 pt-8 border-t border-[#E5DDD0]">
              <p className="text-[10px] tracking-widest text-[#9CA3AF] mb-4" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                {t("contact_biz_label") as string}
              </p>
              <div className="flex flex-col gap-2">
                {bizLinks.map((biz) => (
                  <div key={biz.name} className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: biz.color }} />
                    {biz.url ? (
                      <a
                        href={biz.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-[#1B2A4A] hover:text-[#B8860B] transition-colors"
                        style={{ fontFamily: "'Lato', sans-serif" }}
                      >
                        {biz.name}
                      </a>
                    ) : (
                      <span className="text-sm text-[#9CA3AF]" style={{ fontFamily: "'Lato', sans-serif" }}>
                        {biz.name} <em className="text-xs">{t("contact_soon") as string}</em>
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Form */}
          <div>
            {submitted ? (
              <div
                className="h-full flex flex-col items-center justify-center text-center p-12 border border-[#B8860B]/30"
                style={{ background: "#B8860B08" }}
              >
                <div className="text-6xl text-[#B8860B] mb-6" style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic" }}>
                  شكراً
                </div>
                <h3 className="text-[#1B2A4A] text-2xl font-bold mb-3" style={{ fontFamily: "'Cormorant Garamond', serif" }}>
                  {t("contact_success_title") as string}
                </h3>
                <p className="text-[#6B7280] text-sm leading-relaxed" style={{ fontFamily: "'Lato', sans-serif" }}>
                  {t("contact_success_sub") as string}
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] tracking-widest text-[#9CA3AF] mb-2" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                      {t("contact_form_name") as string}
                    </label>
                    <input type="text" name="name" required value={formData.name} onChange={handleChange}
                      placeholder={t("contact_form_name_ph") as string} className={inputClass} style={{ fontFamily: "'Lato', sans-serif" }} />
                  </div>
                  <div>
                    <label className="block text-[10px] tracking-widest text-[#9CA3AF] mb-2" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                      {t("contact_form_email") as string}
                    </label>
                    <input type="email" name="email" required value={formData.email} onChange={handleChange}
                      placeholder={t("contact_form_email_ph") as string} className={inputClass} style={{ fontFamily: "'Lato', sans-serif" }} />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] tracking-widest text-[#9CA3AF] mb-2" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                    {t("contact_form_company") as string}
                  </label>
                  <input type="text" name="company" value={formData.company} onChange={handleChange}
                    placeholder={t("contact_form_company_ph") as string} className={inputClass} style={{ fontFamily: "'Lato', sans-serif" }} />
                </div>

                <div>
                  <label className="block text-[10px] tracking-widest text-[#9CA3AF] mb-2" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                    {t("contact_form_interest") as string}
                  </label>
                  <select name="interest" value={formData.interest} onChange={handleChange}
                    className={inputClass} style={{ fontFamily: "'Lato', sans-serif" }}>
                    <option value="">{t("contact_form_interest_ph") as string}</option>
                    <option value="raad-sports">{t("contact_interest_sports") as string}</option>
                    <option value="fitt-global">{t("contact_interest_fitt") as string}</option>
                    <option value="handasa">{t("contact_interest_handasa") as string}</option>
                    <option value="star-beauty">{t("contact_interest_beauty") as string}</option>
                    <option value="general">{t("contact_interest_general") as string}</option>
                    <option value="inversiones">{t("contact_interest_invest") as string}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] tracking-widest text-[#9CA3AF] mb-2" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                    {t("contact_form_message") as string}
                  </label>
                  <textarea name="message" required rows={5} value={formData.message} onChange={handleChange}
                    placeholder={t("contact_form_message_ph") as string} className={`${inputClass} resize-none`}
                    style={{ fontFamily: "'Lato', sans-serif" }} />
                </div>

                <button
                  type="submit"
                  className="w-full py-4 bg-[#1B2A4A] text-white text-xs tracking-widest font-semibold hover:bg-[#B8860B] transition-colors duration-300"
                  style={{ fontFamily: "'Montserrat', sans-serif" }}
                >
                  {t("contact_form_submit") as string}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
