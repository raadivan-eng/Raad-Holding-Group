/*
 * RAAD HOLDING GROUP — Portfolio Section
 * Style: Warm Editorial Luxury
 * ES/EN language support
 */

import { useEffect, useRef, useState } from "react";
import { useLang } from "@/contexts/LanguageContext";

const COMPANY_IMAGES = {
  sports: "https://d2xsxph8kpxj0f.cloudfront.net/310519663366769268/5rAkXcv2tyCLbTxCEwe5y8/raad-sports-card-TfbxTchgT3BehZaCLLqnma.webp",
  fitt: "https://d2xsxph8kpxj0f.cloudfront.net/310519663366769268/5rAkXcv2tyCLbTxCEwe5y8/raad-fitt-card-m8jp9GUhAQKvXfMHootFWn.webp",
  handasa: "https://d2xsxph8kpxj0f.cloudfront.net/310519663366769268/5rAkXcv2tyCLbTxCEwe5y8/raad-handasa-card-GxUjAvgRbg23euLrr5GH8X.webp",
  beauty: "https://d2xsxph8kpxj0f.cloudfront.net/310519663366769268/5rAkXcv2tyCLbTxCEwe5y8/raad-beauty-card-Z9W9oTtrKQMfwGyMzW2pSD.webp",
};

function useIntersection(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);
  return { ref, visible };
}

interface CompanyData {
  id: string;
  name: string;
  tagline: string;
  sector: string;
  description: string;
  accentColor: string;
  accentLight: string;
  image: string;
  url: string | null;
  stats: { num: string; label: string }[];
  highlights: string[];
  year: string;
}

function CompanyCard({ company, index, visitLabel, soonLabel }: {
  company: CompanyData;
  index: number;
  visitLabel: string;
  soonLabel: string;
}) {
  const { ref, visible } = useIntersection(0.1);
  const [hovered, setHovered] = useState(false);

  return (
    <div
      ref={ref}
      className="business-card group relative overflow-hidden"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(40px)",
        transition: `opacity 0.7s ease ${index * 0.15}s, transform 0.7s ease ${index * 0.15}s`,
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Image */}
      <div className="relative overflow-hidden" style={{ aspectRatio: "3/4", maxHeight: "520px" }}>
        <img
          src={company.image}
          alt={company.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div
          className="absolute inset-0 transition-opacity duration-500"
          style={{
            background: `linear-gradient(to top, ${company.accentColor}DD 0%, ${company.accentColor}88 40%, transparent 70%)`,
            opacity: hovered ? 1 : 0.75,
          }}
        />
        <div
          className="absolute top-4 right-4 w-12 h-12 flex items-center justify-center text-white/80 border border-white/30 text-[10px] tracking-wider"
          style={{ fontFamily: "'Montserrat', sans-serif", background: "rgba(0,0,0,0.3)", backdropFilter: "blur(4px)" }}
        >
          {company.year}
        </div>
        <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
          <div className="text-[10px] tracking-[0.3em] mb-2 opacity-80" style={{ fontFamily: "'Montserrat', sans-serif" }}>
            {company.sector.toUpperCase()}
          </div>
          <h3 className="text-2xl font-bold leading-tight mb-1" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.75rem" }}>
            {company.name}
          </h3>
          <p className="text-sm opacity-80 italic" style={{ fontFamily: "'Cormorant Garamond', serif" }}>
            {company.tagline}
          </p>
        </div>
      </div>

      {/* Info panel */}
      <div className="p-6 border-l-4" style={{ borderColor: company.accentColor, background: company.accentLight }}>
        <p className="text-sm leading-relaxed mb-4" style={{ fontFamily: "'Lato', sans-serif", color: "#374151" }}>
          {company.description}
        </p>
        <div className="flex gap-6 mb-4">
          {company.stats.map((stat) => (
            <div key={stat.label}>
              <div className="text-2xl font-bold leading-none" style={{ fontFamily: "'Cormorant Garamond', serif", color: company.accentColor, fontStyle: "italic" }}>
                {stat.num}
              </div>
              <div className="text-[10px] tracking-wider mt-0.5" style={{ fontFamily: "'Montserrat', sans-serif", color: "#6B7280" }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>
        <div className="flex flex-wrap gap-2 mb-5">
          {company.highlights.map((h) => (
            <span
              key={h}
              className="text-[10px] px-2.5 py-1 tracking-wider border"
              style={{ fontFamily: "'Montserrat', sans-serif", color: company.accentColor, borderColor: `${company.accentColor}40`, background: "white" }}
            >
              {h}
            </span>
          ))}
        </div>
        {company.url ? (
          <a
            href={company.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-xs tracking-widest font-semibold transition-all duration-300 hover:gap-4"
            style={{ fontFamily: "'Montserrat', sans-serif", color: company.accentColor }}
          >
            {visitLabel}
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </a>
        ) : (
          <span className="inline-flex items-center gap-2 text-xs tracking-widest font-semibold opacity-50" style={{ fontFamily: "'Montserrat', sans-serif", color: company.accentColor }}>
            {soonLabel}
          </span>
        )}
      </div>
    </div>
  );
}

export default function Portfolio() {
  const { ref: titleRef, visible: titleVisible } = useIntersection(0.2);
  const { t } = useLang();

  const companies: CompanyData[] = [
    {
      id: "raad-sports",
      name: "Raad Sports",
      tagline: t("company_sports_tagline") as string,
      sector: t("company_sports_sector") as string,
      description: t("company_sports_desc") as string,
      accentColor: "#1E40AF",
      accentLight: "#EFF6FF",
      image: COMPANY_IMAGES.sports,
      url: "https://raad-sports-m9j8tkfj.manus.space/",
      stats: [
        { num: "500+", label: t("company_sports_stat_1") as string },
        { num: "150+", label: t("company_sports_stat_2") as string },
      ],
      highlights: ["Representación Deportiva", "Plataforma CATCH con IA", "Playermaker Technology"],
      year: "2020",
    },
    {
      id: "fitt-global",
      name: "Fitt Global",
      tagline: t("company_fitt_tagline") as string,
      sector: t("company_fitt_sector") as string,
      description: t("company_fitt_desc") as string,
      accentColor: "#4D7C0F",
      accentLight: "#F0FDF4",
      image: COMPANY_IMAGES.fitt,
      url: "https://fittglobal-qjwiezeo.manus.space",
      stats: [
        { num: "253+", label: t("company_fitt_stat_1") as string },
        { num: "10+", label: t("company_fitt_stat_2") as string },
      ],
      highlights: ["The Protein Choice", "Ross D'Elen", "SmartShake"],
      year: "2013",
    },
    {
      id: "handasa",
      name: "Handasa",
      tagline: t("company_handasa_tagline") as string,
      sector: t("company_handasa_sector") as string,
      description: t("company_handasa_desc") as string,
      accentColor: "#4A5E2A",
      accentLight: "#F7FEE7",
      image: COMPANY_IMAGES.handasa,
      url: "https://handasa-env-dghx92zu.manus.space",
      stats: [
        { num: "47+", label: t("company_handasa_stat_1") as string },
        { num: "30+", label: t("company_handasa_stat_2") as string },
      ],
      highlights: ["Plantas de Tratamiento", "Gestión Ambiental", "Consultoría Pública"],
      year: "1979",
    },
    {
      id: "star-beauty",
      name: "Star Beauty Brands",
      tagline: t("company_beauty_tagline") as string,
      sector: t("company_beauty_sector") as string,
      description: t("company_beauty_desc") as string,
      accentColor: "#9D4E6B",
      accentLight: "#FFF1F5",
      image: COMPANY_IMAGES.beauty,
      url: null,
      stats: [
        { num: "Excl.", label: t("company_beauty_stat_1") as string },
        { num: "Col.", label: t("company_beauty_stat_2") as string },
      ],
      highlights: ["Wet n Wild Colombia", "Farmatodo", "Locatel"],
      year: "2022",
    },
  ];

  return (
    <section id="portafolio" className="py-28 bg-[#FAF7F2]">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        {/* Section header */}
        <div
          ref={titleRef}
          className="mb-20"
          style={{
            opacity: titleVisible ? 1 : 0,
            transform: titleVisible ? "translateY(0)" : "translateY(30px)",
            transition: "opacity 0.7s ease, transform 0.7s ease",
          }}
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-px bg-[#B8860B]" />
            <span className="text-[#B8860B] text-xs tracking-[0.4em] font-medium" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              {t("portfolio_eyebrow") as string}
            </span>
          </div>
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
            <h2
              className="text-[#1B2A4A] leading-tight"
              style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(2.5rem, 5vw, 4rem)", fontWeight: 700 }}
            >
              {t("portfolio_headline_1") as string}
              <br />
              <em className="text-[#B8860B]">{t("portfolio_headline_2") as string}</em>
            </h2>
            <p className="text-[#6B7280] max-w-sm leading-relaxed text-sm" style={{ fontFamily: "'Lato', sans-serif" }}>
              {t("portfolio_sub") as string}
            </p>
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          {companies.map((company, index) => (
            <CompanyCard
              key={company.id}
              company={company}
              index={index}
              visitLabel={t("portfolio_visit") as string}
              soonLabel={t("portfolio_soon") as string}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
