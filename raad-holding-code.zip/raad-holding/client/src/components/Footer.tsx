/*
 * RAAD HOLDING GROUP — Footer
 * Style: Warm Editorial Luxury
 * ES/EN language support
 */

import { useLang } from "@/contexts/LanguageContext";

export default function Footer() {
  const year = new Date().getFullYear();
  const { t } = useLang();

  const bizLinks = [
    { name: "Raad Sports", url: "https://raad-sports-m9j8tkfj.manus.space/", descKey: "company_sports_footer" },
    { name: "Fitt Global", url: "https://fittglobal-qjwiezeo.manus.space", descKey: "company_fitt_footer" },
    { name: "Handasa", url: "https://handasa-env-dghx92zu.manus.space", descKey: "company_handasa_footer" },
    { name: "Star Beauty Brands", url: null, descKey: "company_beauty_footer" },
  ];

  return (
    <footer className="bg-[#0D1929] text-white">
      <div className="h-px w-full bg-gradient-to-r from-transparent via-[#B8860B] to-transparent" />

      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div>
            <div className="mb-4">
              <div
                className="text-3xl font-bold tracking-widest text-white"
                style={{ fontFamily: "'Cormorant Garamond', serif", letterSpacing: "0.15em" }}
              >
                RAAD
              </div>
              <div
                className="text-[9px] tracking-[0.35em] text-[#B8860B] font-medium"
                style={{ fontFamily: "'Montserrat', sans-serif" }}
              >
                HOLDING GROUP
              </div>
            </div>
            <p className="text-white/50 text-sm leading-relaxed" style={{ fontFamily: "'Lato', sans-serif" }}>
              {t("footer_desc") as string}
            </p>
            <p
              className="text-[#B8860B]/40 text-lg mt-4"
              style={{ fontFamily: "'Cormorant Garamond', serif", direction: "rtl" }}
            >
              {t("footer_arabic") as string}
            </p>
          </div>

          {/* Companies */}
          <div>
            <p className="text-[10px] tracking-[0.3em] text-[#B8860B] mb-5 font-medium" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              {t("footer_companies") as string}
            </p>
            <div className="space-y-3">
              {bizLinks.map((biz) => (
                <div key={biz.name} className="flex flex-col">
                  {biz.url ? (
                    <a
                      href={biz.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-white/80 text-sm hover:text-[#B8860B] transition-colors animated-link"
                      style={{ fontFamily: "'Lato', sans-serif" }}
                    >
                      {biz.name}
                    </a>
                  ) : (
                    <span className="text-white/40 text-sm" style={{ fontFamily: "'Lato', sans-serif" }}>
                      {biz.name}
                    </span>
                  )}
                  <span className="text-white/30 text-xs" style={{ fontFamily: "'Lato', sans-serif" }}>
                    {t(biz.descKey as any) as string}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div>
            <p className="text-[10px] tracking-[0.3em] text-[#B8860B] mb-5 font-medium" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              {t("footer_contact") as string}
            </p>
            <div className="space-y-3">
              <div>
                <p className="text-white/30 text-xs mb-0.5" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                  {t("footer_email_label") as string}
                </p>
                <a href="mailto:info@fittglobal.com" className="text-white/70 text-sm hover:text-[#B8860B] transition-colors" style={{ fontFamily: "'Lato', sans-serif" }}>
                  info@fittglobal.com
                </a>
              </div>
              <div>
                <p className="text-white/30 text-xs mb-0.5" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                  {t("footer_phone_label") as string}
                </p>
                <a href="https://wa.me/573003323856" target="_blank" rel="noopener noreferrer" className="text-white/70 text-sm hover:text-[#B8860B] transition-colors" style={{ fontFamily: "'Lato', sans-serif" }}>
                  +57 300 332 3856
                </a>
              </div>
              <div>
                <p className="text-white/30 text-xs mb-0.5" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                  {t("footer_location_label") as string}
                </p>
                <p className="text-white/70 text-sm whitespace-pre-line" style={{ fontFamily: "'Lato', sans-serif" }}>
                  {t("footer_location_value") as string}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-white/30 text-xs" style={{ fontFamily: "'Lato', sans-serif" }}>
            © {year} Raad Holding Group. {t("footer_rights") as string}
          </p>
          <p className="text-white/20 text-xs italic" style={{ fontFamily: "'Cormorant Garamond', serif" }}>
            {t("footer_tagline") as string}
          </p>
        </div>
      </div>
    </footer>
  );
}
