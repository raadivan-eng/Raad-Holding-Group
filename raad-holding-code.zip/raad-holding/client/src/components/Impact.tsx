/*
 * RAAD HOLDING GROUP — Impact / Stats Section
 * Style: Warm Editorial Luxury
 * ES/EN language support
 */

import { useEffect, useRef, useState } from "react";
import { useLang } from "@/contexts/LanguageContext";

function useIntersection(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);
  return { ref, visible };
}

function CountUp({ target, suffix = "" }: { target: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const { ref, visible } = useIntersection(0.3);

  useEffect(() => {
    if (!visible) return;
    const duration = 1800;
    const steps = 60;
    const increment = target / steps;
    let current = 0;
    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);
    return () => clearInterval(timer);
  }, [visible, target]);

  return <span ref={ref}>{count}{suffix}</span>;
}

export default function Impact() {
  const { ref: titleRef, visible: titleVisible } = useIntersection(0.2);
  const { t } = useLang();

  const STATS = [
    { num: 4, suffix: "", labelKey: "impact_stat_1_label", descKey: "impact_stat_1_desc", color: "#B8860B" },
    { num: 500, suffix: "+", labelKey: "impact_stat_2_label", descKey: "impact_stat_2_desc", color: "#1E40AF" },
    { num: 253, suffix: "+", labelKey: "impact_stat_3_label", descKey: "impact_stat_3_desc", color: "#4D7C0F" },
    { num: 47, suffix: "+", labelKey: "impact_stat_4_label", descKey: "impact_stat_4_desc", color: "#4A5E2A" },
    { num: 2, suffix: "", labelKey: "impact_stat_5_label", descKey: "impact_stat_5_desc", color: "#9D4E6B" },
    { num: 10, suffix: "+", labelKey: "impact_stat_6_label", descKey: "impact_stat_6_desc", color: "#B8860B" },
  ];

  return (
    <section className="py-28 bg-white relative overflow-hidden">
      <div
        className="absolute top-0 right-0 text-[20rem] font-bold text-[#1B2A4A]/3 leading-none select-none pointer-events-none"
        style={{ fontFamily: "'Cormorant Garamond', serif", transform: "translateY(-20%)" }}
      >
        رعد
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <div
          ref={titleRef}
          className="mb-16"
          style={{
            opacity: titleVisible ? 1 : 0,
            transform: titleVisible ? "translateY(0)" : "translateY(30px)",
            transition: "opacity 0.7s ease, transform 0.7s ease",
          }}
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-px bg-[#B8860B]" />
            <span className="text-[#B8860B] text-xs tracking-[0.4em] font-medium" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              {t("impact_eyebrow") as string}
            </span>
          </div>
          <h2
            className="text-[#1B2A4A] leading-tight"
            style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(2rem, 4vw, 3.5rem)", fontWeight: 700 }}
          >
            {t("impact_headline_1") as string}
            <br />
            <em className="text-[#B8860B]">{t("impact_headline_2") as string}</em>
          </h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-0">
          {STATS.map((stat) => (
            <div
              key={stat.labelKey}
              className="p-8 border border-[#E5DDD0] relative group hover:bg-[#FAF7F2] transition-colors duration-300"
            >
              <div
                className="absolute top-0 left-0 w-full h-0.5 transition-transform duration-300 origin-left scale-x-0 group-hover:scale-x-100"
                style={{ background: stat.color }}
              />
              <div
                className="text-5xl font-bold leading-none mb-2"
                style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic", color: stat.color }}
              >
                <CountUp target={stat.num} suffix={stat.suffix} />
              </div>
              <div className="text-[#1B2A4A] font-semibold text-sm mb-1" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                {t(stat.labelKey as any) as string}
              </div>
              <div className="text-[#9CA3AF] text-xs leading-relaxed" style={{ fontFamily: "'Lato', sans-serif" }}>
                {t(stat.descKey as any) as string}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
