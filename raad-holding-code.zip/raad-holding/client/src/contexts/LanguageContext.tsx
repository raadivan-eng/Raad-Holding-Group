/*
 * RAAD HOLDING GROUP — Language Context
 * Provides ES/EN translations for all page content
 */

import { createContext, useContext, useState, ReactNode } from "react";

type Lang = "es" | "en";

const translations = {
  es: {
    // Navbar
    nav_inicio: "Inicio",
    nav_portafolio: "Portafolio",
    nav_nosotros: "Nosotros",
    nav_contacto: "Contacto",

    // Hero
    hero_location: "BARRANQUILLA · COLOMBIA",
    hero_headline_1: "Construyendo",
    hero_headline_2: "legado",
    hero_headline_3: "en cada sector.",
    hero_sub: "Un grupo empresarial familiar con presencia en deportes, nutrición, ingeniería ambiental y cosméticos. Impulsando el desarrollo de Colombia desde la Costa Caribe.",
    hero_cta_portfolio: "NUESTRO PORTAFOLIO",
    hero_cta_about: "CONOCER MÁS",
    hero_stat_1_label: "Unidades de Negocio",
    hero_stat_2_label: "Años de Trayectoria",
    hero_stat_3_label: "Atletas Representados",
    hero_stat_4_label: "Puntos de Distribución",

    // Portfolio
    portfolio_eyebrow: "NUESTRO PORTAFOLIO",
    portfolio_headline_1: "Cuatro sectores,",
    portfolio_headline_2: "una sola visión.",
    portfolio_sub: "Cada unidad de negocio opera con autonomía e identidad propia, respaldada por el legado y los valores del grupo familiar Raad.",
    portfolio_visit: "VISITAR SITIO",
    portfolio_soon: "PRÓXIMAMENTE",

    // Companies
    company_sports_sector: "Deportes & Tecnología",
    company_sports_tagline: "Encontremos tu grandeza",
    company_sports_desc: "Impulsamos el potencial de deportistas con inteligencia artificial, análisis objetivos y estrategia personalizada. Representación deportiva, plataforma estudiantil-atleta y tecnología de sensores inteligentes.",
    company_sports_stat_1: "Atletas",
    company_sports_stat_2: "Universidades",

    company_fitt_sector: "Nutrición & Distribución",
    company_fitt_tagline: "Aliado estratégico en nutrición deportiva",
    company_fitt_desc: "Distribuidor líder de suplementos deportivos y nutricionales en Colombia y Centro América. Desde Barranquilla, impulsamos el crecimiento de marcas líderes a través de soluciones innovadoras.",
    company_fitt_stat_1: "Puntos Retail",
    company_fitt_stat_2: "Años",

    company_handasa_sector: "Ingeniería Civil & Ambiental",
    company_handasa_tagline: "Ingeniería que transforma el territorio",
    company_handasa_desc: "Firma de consultoría con más de 47 años de experiencia en diseño y gestión de proyectos de infraestructura sanitaria, hidráulica y ambiental en toda la región Caribe colombiana.",
    company_handasa_stat_1: "Años",
    company_handasa_stat_2: "Proyectos",

    company_beauty_sector: "Cosméticos & Distribución",
    company_beauty_tagline: "Belleza accesible para todas",
    company_beauty_desc: "Distribuidores exclusivos de Wet n Wild en Colombia. Llevamos la mejor cosmética internacional a las principales cadenas del país, con presencia en Farmatodo, Locatel y más.",
    company_beauty_stat_1: "Distribución",
    company_beauty_stat_2: "Cobertura",

    // Impact
    impact_eyebrow: "NUESTRO IMPACTO",
    impact_headline_1: "Números que",
    impact_headline_2: "hablan por sí solos.",
    impact_stat_1_label: "Unidades de Negocio",
    impact_stat_1_desc: "Deportes, nutrición, ingeniería y cosméticos",
    impact_stat_2_label: "Atletas Representados",
    impact_stat_2_desc: "A través de Raad Sports en Colombia y el exterior",
    impact_stat_3_label: "Puntos de Distribución",
    impact_stat_3_desc: "Fitt Global en Colombia y Centro América",
    impact_stat_4_label: "Años de Ingeniería",
    impact_stat_4_desc: "Handasa transformando la región Caribe",
    impact_stat_5_label: "Países",
    impact_stat_5_desc: "Colombia y Costa Rica con proyección regional",
    impact_stat_6_label: "Años en Nutrición",
    impact_stat_6_desc: "Distribución de marcas internacionales premium",

    // About
    about_eyebrow: "QUIÉNES SOMOS",
    about_headline_1: "Un legado familiar",
    about_headline_2: "construido con propósito.",
    about_p1: "Raad Holding Group nació de la visión compartida de los hermanos Raad Gilede, una familia de origen árabe radicada en Barranquilla, Colombia. Con formación internacional y un profundo arraigo en la Costa Caribe, fundaron empresas que reflejan su diversidad de talentos y su compromiso con la excelencia.",
    about_p2: "Desde la representación de atletas de alto rendimiento hasta la distribución de marcas internacionales de nutrición y cosméticos, pasando por décadas de ingeniería ambiental que han transformado comunidades enteras, el grupo Raad opera con una filosofía clara:",
    about_p2_em: "cada negocio debe crear valor real para las personas y el territorio.",
    about_p3: "Con sede principal en Barranquilla y presencia en Bogotá, Colombia y Centro América, el grupo continúa expandiéndose con la misma solidez y valores que lo han caracterizado desde sus inicios.",
    about_founders_label: "SOCIOS FUNDADORES",
    about_founders: [
      { name: "Fuad Raad Gilede", role: "Banca & Finanzas" },
      { name: "Gustavo Raad Gilede", role: "Diseño Industrial" },
      { name: "Alvaro Raad Gilede", role: "Negocios Internacionales" },
      { name: "Iván Raad Gilede", role: "Economía Internacional" },
    ],
    about_hq_label: "SEDE PRINCIPAL",
    about_hq_city: "Barranquilla, Atlántico",
    about_hq_sub: "Costa Caribe Colombiana · Presencia en 2 países",
    about_values_label: "NUESTROS VALORES",
    about_values: [
      { arabic: "عائلة", label: "Familia", description: "Un grupo fundado y dirigido por hermanos, con valores compartidos que trascienden los negocios." },
      { arabic: "إبداع", label: "Innovación", description: "Adoptamos tecnología de vanguardia en cada sector para mantenernos a la delantera." },
      { arabic: "نزاهة", label: "Integridad", description: "Operamos con transparencia, cumplimiento normativo y respeto por nuestros aliados." },
      { arabic: "نمو", label: "Crecimiento", description: "Buscamos el desarrollo sostenible de Colombia y la región Caribe en cada proyecto." },
    ],

    // Contact
    contact_eyebrow: "CONTACTO",
    contact_headline_1: "Hablemos de",
    contact_headline_2: "oportunidades.",
    contact_sub: "Ya sea que busques un aliado estratégico, una oportunidad de inversión o simplemente quieras conocer más sobre nuestras empresas, estamos disponibles para conversar.",
    contact_email_label: "Correo General",
    contact_phone_label: "WhatsApp",
    contact_location_label: "Ubicación",
    contact_location_value: "Barranquilla, Atlántico, Colombia",
    contact_biz_label: "NUESTRAS EMPRESAS",
    contact_form_name: "NOMBRE *",
    contact_form_email: "CORREO *",
    contact_form_company: "EMPRESA / ORGANIZACIÓN",
    contact_form_interest: "ÁREA DE INTERÉS",
    contact_form_message: "MENSAJE *",
    contact_form_submit: "ENVIAR MENSAJE",
    contact_form_name_ph: "Tu nombre",
    contact_form_email_ph: "tu@email.com",
    contact_form_company_ph: "Nombre de tu empresa",
    contact_form_interest_ph: "Seleccionar...",
    contact_form_message_ph: "¿En qué podemos ayudarte?",
    contact_interest_sports: "Raad Sports",
    contact_interest_fitt: "Fitt Global",
    contact_interest_handasa: "Handasa",
    contact_interest_beauty: "Star Beauty Brands",
    contact_interest_general: "Información General",
    contact_interest_invest: "Oportunidades de Inversión",
    contact_success_title: "Mensaje recibido",
    contact_success_sub: "Gracias por contactarnos. Nos pondremos en comunicación contigo a la brevedad posible.",
    contact_soon: "(próximamente)",

    // Footer
    footer_desc: "Conglomerado empresarial familiar con presencia en deportes, nutrición, ingeniería ambiental y cosméticos. Barranquilla, Colombia.",
    footer_companies: "NUESTRAS EMPRESAS",
    footer_contact: "CONTACTO",
    footer_email_label: "CORREO",
    footer_phone_label: "WHATSAPP",
    footer_location_label: "UBICACIÓN",
    footer_location_value: "Barranquilla, Atlántico\nColombia",
    footer_rights: "Todos los derechos reservados.",
    footer_tagline: "Barranquilla · Colombia · Centro América",
    footer_arabic: "بناء الإرث",

    // Company descriptions in footer
    company_sports_footer: "Deportes & Tecnología",
    company_fitt_footer: "Nutrición & Distribución",
    company_handasa_footer: "Ingeniería Civil & Ambiental",
    company_beauty_footer: "Cosméticos & Distribución",
  },

  en: {
    // Navbar
    nav_inicio: "Home",
    nav_portafolio: "Portfolio",
    nav_nosotros: "About",
    nav_contacto: "Contact",

    // Hero
    hero_location: "BARRANQUILLA · COLOMBIA",
    hero_headline_1: "Building",
    hero_headline_2: "legacy",
    hero_headline_3: "across every sector.",
    hero_sub: "A family-owned business group with presence in sports, nutrition, environmental engineering and cosmetics. Driving Colombia's development from the Caribbean Coast.",
    hero_cta_portfolio: "OUR PORTFOLIO",
    hero_cta_about: "LEARN MORE",
    hero_stat_1_label: "Business Units",
    hero_stat_2_label: "Years of Experience",
    hero_stat_3_label: "Athletes Represented",
    hero_stat_4_label: "Distribution Points",

    // Portfolio
    portfolio_eyebrow: "OUR PORTFOLIO",
    portfolio_headline_1: "Four sectors,",
    portfolio_headline_2: "one single vision.",
    portfolio_sub: "Each business unit operates with its own autonomy and identity, backed by the legacy and values of the Raad family group.",
    portfolio_visit: "VISIT SITE",
    portfolio_soon: "COMING SOON",

    // Companies
    company_sports_sector: "Sports & Technology",
    company_sports_tagline: "Let's find your greatness",
    company_sports_desc: "We unlock the potential of athletes through artificial intelligence, objective analysis and personalized strategy. Sports representation, student-athlete platform and smart sensor technology.",
    company_sports_stat_1: "Athletes",
    company_sports_stat_2: "Universities",

    company_fitt_sector: "Nutrition & Distribution",
    company_fitt_tagline: "Your strategic partner in sports nutrition",
    company_fitt_desc: "Leading distributor of sports and nutritional supplements in Colombia and Central America. From Barranquilla, we drive the growth of leading brands through innovative solutions.",
    company_fitt_stat_1: "Retail Points",
    company_fitt_stat_2: "Years",

    company_handasa_sector: "Civil & Environmental Engineering",
    company_handasa_tagline: "Engineering that transforms the territory",
    company_handasa_desc: "Consulting firm with over 47 years of experience in the design and management of sanitary, hydraulic and environmental infrastructure projects across the Colombian Caribbean region.",
    company_handasa_stat_1: "Years",
    company_handasa_stat_2: "Projects",

    company_beauty_sector: "Cosmetics & Distribution",
    company_beauty_tagline: "Accessible beauty for everyone",
    company_beauty_desc: "Exclusive distributors of Wet n Wild in Colombia. We bring the best international cosmetics to the country's leading retail chains, with presence in Farmatodo, Locatel and more.",
    company_beauty_stat_1: "Distribution",
    company_beauty_stat_2: "Coverage",

    // Impact
    impact_eyebrow: "OUR IMPACT",
    impact_headline_1: "Numbers that",
    impact_headline_2: "speak for themselves.",
    impact_stat_1_label: "Business Units",
    impact_stat_1_desc: "Sports, nutrition, engineering and cosmetics",
    impact_stat_2_label: "Athletes Represented",
    impact_stat_2_desc: "Through Raad Sports in Colombia and abroad",
    impact_stat_3_label: "Distribution Points",
    impact_stat_3_desc: "Fitt Global across Colombia and Central America",
    impact_stat_4_label: "Years in Engineering",
    impact_stat_4_desc: "Handasa transforming the Caribbean region",
    impact_stat_5_label: "Countries",
    impact_stat_5_desc: "Colombia and Costa Rica with regional expansion",
    impact_stat_6_label: "Years in Nutrition",
    impact_stat_6_desc: "Distributing premium international brands",

    // About
    about_eyebrow: "WHO WE ARE",
    about_headline_1: "A family legacy",
    about_headline_2: "built with purpose.",
    about_p1: "Raad Holding Group was born from the shared vision of the Raad Gilede brothers, a family of Arab heritage based in Barranquilla, Colombia. With international education and deep roots in the Caribbean Coast, they founded companies that reflect their diversity of talents and commitment to excellence.",
    about_p2: "From representing elite athletes to distributing international nutrition and cosmetics brands, through decades of environmental engineering that have transformed entire communities, the Raad group operates with a clear philosophy:",
    about_p2_em: "every business must create real value for people and the territory.",
    about_p3: "Headquartered in Barranquilla with presence in Bogotá, Colombia and Central America, the group continues to expand with the same strength and values that have defined it from the very beginning.",
    about_founders_label: "FOUNDING PARTNERS",
    about_founders: [
      { name: "Fuad Raad Gilede", role: "Banking & Finance" },
      { name: "Gustavo Raad Gilede", role: "Industrial Design" },
      { name: "Alvaro Raad Gilede", role: "International Business" },
      { name: "Iván Raad Gilede", role: "International Economics" },
    ],
    about_hq_label: "HEADQUARTERS",
    about_hq_city: "Barranquilla, Atlántico",
    about_hq_sub: "Colombian Caribbean Coast · Presence in 2 countries",
    about_values_label: "OUR VALUES",
    about_values: [
      { arabic: "عائلة", label: "Family", description: "A group founded and led by brothers, with shared values that transcend business." },
      { arabic: "إبداع", label: "Innovation", description: "We adopt cutting-edge technology in every sector to stay ahead of the curve." },
      { arabic: "نزاهة", label: "Integrity", description: "We operate with transparency, regulatory compliance and respect for our partners." },
      { arabic: "نمو", label: "Growth", description: "We pursue the sustainable development of Colombia and the Caribbean region in every project." },
    ],

    // Contact
    contact_eyebrow: "CONTACT",
    contact_headline_1: "Let's talk about",
    contact_headline_2: "opportunities.",
    contact_sub: "Whether you're looking for a strategic partner, an investment opportunity, or simply want to learn more about our companies, we're available to talk.",
    contact_email_label: "General Email",
    contact_phone_label: "WhatsApp",
    contact_location_label: "Location",
    contact_location_value: "Barranquilla, Atlántico, Colombia",
    contact_biz_label: "OUR COMPANIES",
    contact_form_name: "NAME *",
    contact_form_email: "EMAIL *",
    contact_form_company: "COMPANY / ORGANIZATION",
    contact_form_interest: "AREA OF INTEREST",
    contact_form_message: "MESSAGE *",
    contact_form_submit: "SEND MESSAGE",
    contact_form_name_ph: "Your name",
    contact_form_email_ph: "you@email.com",
    contact_form_company_ph: "Your company name",
    contact_form_interest_ph: "Select...",
    contact_form_message_ph: "How can we help you?",
    contact_interest_sports: "Raad Sports",
    contact_interest_fitt: "Fitt Global",
    contact_interest_handasa: "Handasa",
    contact_interest_beauty: "Star Beauty Brands",
    contact_interest_general: "General Information",
    contact_interest_invest: "Investment Opportunities",
    contact_success_title: "Message received",
    contact_success_sub: "Thank you for reaching out. We will get back to you as soon as possible.",
    contact_soon: "(coming soon)",

    // Footer
    footer_desc: "Family-owned business group with presence in sports, nutrition, environmental engineering and cosmetics. Barranquilla, Colombia.",
    footer_companies: "OUR COMPANIES",
    footer_contact: "CONTACT",
    footer_email_label: "EMAIL",
    footer_phone_label: "WHATSAPP",
    footer_location_label: "LOCATION",
    footer_location_value: "Barranquilla, Atlántico\nColombia",
    footer_rights: "All rights reserved.",
    footer_tagline: "Barranquilla · Colombia · Central America",
    footer_arabic: "بناء الإرث",

    // Company descriptions in footer
    company_sports_footer: "Sports & Technology",
    company_fitt_footer: "Nutrition & Distribution",
    company_handasa_footer: "Civil & Environmental Engineering",
    company_beauty_footer: "Cosmetics & Distribution",
  },
} as const;

type Translations = typeof translations.es;
type TranslationKey = keyof Translations;

interface LanguageContextType {
  lang: Lang;
  toggleLang: () => void;
  t: (key: TranslationKey) => string | typeof translations.es[typeof key];
}

const LanguageContext = createContext<LanguageContextType | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>("es");

  const toggleLang = () => setLang((l) => (l === "es" ? "en" : "es"));

  const t = (key: TranslationKey) => {
    return (translations[lang] as Translations)[key];
  };

  return (
    <LanguageContext.Provider value={{ lang, toggleLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLang() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLang must be used within LanguageProvider");
  return ctx;
}
