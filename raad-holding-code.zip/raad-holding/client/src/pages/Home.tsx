/*
 * RAAD HOLDING GROUP — Home Page
 * Style: Warm Editorial Luxury
 * Assembles all sections in order
 */

import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Portfolio from "@/components/Portfolio";
import Impact from "@/components/Impact";
import About from "@/components/About";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <Hero />
      <Portfolio />
      <Impact />
      <About />
      <Contact />
      <Footer />
    </div>
  );
}
